#!/usr/bin/env python3
"""
Reproducible Titanic EDA generator.

Usage:
  python generate_eda.py [--train PATH] [--test PATH] [--gender PATH]

If paths are omitted, defaults are train.csv, test.csv, and gender_submission.csv in the same directory.
"""

import os
import argparse
from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def save_fig(path, figsize=(8,5)):
    fig = plt.gcf()
    fig.set_size_inches(figsize[0], figsize[1])
    plt.tight_layout()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=144)
    plt.close(fig)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", default="train.csv")
    parser.add_argument("--test", default="test.csv")
    parser.add_argument("--gender", default="gender_submission.csv")
    args = parser.parse_args()

    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    docs_dir = os.path.join(base_dir, "docs")
    assets_dir = os.path.join(docs_dir, "assets")
    os.makedirs(assets_dir, exist_ok=True)

    # Data
    train = pd.read_csv(os.path.join(base_dir, args.train)) if not os.path.isabs(args.train) else pd.read_csv(args.train)
    test = pd.read_csv(os.path.join(base_dir, args.test)) if not os.path.isabs(args.test) else pd.read_csv(args.test)
    gender_sub = pd.read_csv(os.path.join(base_dir, args.gender)) if not os.path.isabs(args.gender) else pd.read_csv(args.gender)

    df = train.copy()
    df["Embarked"] = df["Embarked"].fillna("Unknown")
    df["FamilySize"] = df["SibSp"] + df["Parch"] + 1

    # Basic stats
    missing = df.isna().sum().to_frame("MissingCount")
    missing["MissingPct"] = (missing["MissingCount"] / len(df) * 100).round(2)
    target_counts = df["Survived"].value_counts().sort_index()
    gender_survival = df.groupby("Sex")["Survived"].mean().sort_values(ascending=False)
    pclass_survival = df.groupby("Pclass")["Survived"].mean().sort_index()
    embarked_survival = df.groupby("Embarked")["Survived"].mean().sort_values(ascending=False)
    family_survival = df.groupby("FamilySize")["Survived"].mean()
    corr = df.select_dtypes(include=["number"]).corr(numeric_only=True)
    if "Survived" in corr.columns:
        corr_with_target = (
            corr["Survived"].drop(labels=["Survived"]).sort_values(key=lambda s: s.abs(), ascending=False).round(3)
            .to_frame("CorrelationWithSurvived")
        )
    else:
        corr_with_target = pd.DataFrame(columns=["CorrelationWithSurvived"])

    # Charts (matplotlib only, no seaborn, one chart per figure, no explicit colors)
    # 1) Target distribution
    plt.figure()
    ax = plt.gca()
    ax.bar(["Not Survived (0)", "Survived (1)"], [target_counts.get(0, 0), target_counts.get(1, 0)])
    ax.set_title("Target distribution: Survived")
    ax.set_ylabel("Count")
    save_fig(os.path.join(assets_dir, "01_target_distribution.png"))

    # 2) Survival by Sex
    plt.figure()
    ax = plt.gca()
    ax.bar(gender_survival.index.astype(str), gender_survival.values)
    ax.set_title("Survival rate by Sex")
    ax.set_ylabel("Survival rate")
    save_fig(os.path.join(assets_dir, "02_survival_by_sex.png"))

    # 3) Survival by Pclass
    plt.figure()
    ax = plt.gca()
    ax.bar(pclass_survival.index.astype(str), pclass_survival.values)
    ax.set_title("Survival rate by Pclass")
    ax.set_xlabel("Pclass")
    ax.set_ylabel("Survival rate")
    save_fig(os.path.join(assets_dir, "03_survival_by_pclass.png"))

    # 4) Survival by Embarked
    plt.figure()
    ax = plt.gca()
    ax.bar(embarked_survival.index.astype(str), embarked_survival.values)
    ax.set_title("Survival rate by Embarked")
    ax.set_ylabel("Survival rate")
    save_fig(os.path.join(assets_dir, "04_survival_by_embarked.png"))

    # 5) Age by outcome
    plt.figure()
    ax = plt.gca()
    surv_age = df.loc[df["Survived"] == 1, "Age"].dropna()
    not_surv_age = df.loc[df["Survived"] == 0, "Age"].dropna()
    bins = np.linspace(0, 80, 21)
    ax.hist(surv_age, bins=bins, alpha=0.7, label="Survived")
    ax.hist(not_surv_age, bins=bins, alpha=0.7, label="Not Survived")
    ax.set_title("Age distribution by outcome")
    ax.set_xlabel("Age")
    ax.set_ylabel("Count")
    ax.legend()
    save_fig(os.path.join(assets_dir, "05_age_by_outcome.png"), figsize=(9,5))

    # 6) Fare distribution (log)
    plt.figure()
    ax = plt.gca()
    fare = df["Fare"].dropna()
    ax.hist(fare, bins=30)
    ax.set_xscale("log")
    ax.set_title("Fare distribution (log-scaled x)")
    ax.set_xlabel("Fare (log scale)")
    ax.set_ylabel("Count")
    save_fig(os.path.join(assets_dir, "06_fare_distribution_log.png"))

    # 7) Missingness heatmap
    plt.figure()
    ax = plt.gca()
    ax.imshow(df.isna(), aspect="auto", interpolation="nearest")
    ax.set_title("Missingness heatmap (rows x columns)")
    ax.set_xlabel("Columns")
    ax.set_ylabel("Rows")
    ax.set_xticks(range(len(df.columns)))
    ax.set_xticklabels(df.columns, rotation=45, ha="right")
    save_fig(os.path.join(assets_dir, "07_missingness_heatmap.png"), figsize=(10,6))

    # 8) Correlation heatmap
    plt.figure()
    ax = plt.gca()
    im = ax.imshow(corr.values, aspect="auto", interpolation="nearest", vmin=-1, vmax=1)
    ax.set_title("Correlation heatmap (numeric features)")
    ax.set_xticks(range(len(corr.columns)))
    ax.set_xticklabels(corr.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(corr.index)))
    ax.set_yticklabels(corr.index)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    save_fig(os.path.join(assets_dir, "08_correlation_heatmap.png"), figsize=(8.5,7))

    # 9) FamilySize
    plt.figure()
    ax = plt.gca()
    fs_sorted = df.groupby("FamilySize")["Survived"].mean().sort_index()
    ax.bar(fs_sorted.index.astype(str), fs_sorted.values)
    ax.set_title("Survival rate by FamilySize")
    ax.set_xlabel("FamilySize (SibSp + Parch + 1)")
    ax.set_ylabel("Survival rate")
    save_fig(os.path.join(assets_dir, "09_family_size_survival.png"), figsize=(9.5,5))

    # Build HTML (simple)
    def df_to_html_table(df: pd.DataFrame, index=True):
        return df.to_html(classes="table", border=0, index=index)

    generated_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    missing_sorted = missing.sort_values("MissingPct", ascending=False)
    high_missing = missing_sorted[missing_sorted["MissingPct"] >= 30.0]

    index_html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Titanic EDA – GitHub Pages</title>
  <style>
    body {{ font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; line-height: 1.55; margin: 0; padding: 0; }}
    header {{ background: #111; color: #fff; padding: 24px; }}
    main {{ max-width: 1100px; margin: 0 auto; padding: 24px; }}
    h1, h2, h3 {{ line-height: 1.2; }}
    .summary ul {{ list-style: disc; padding-left: 20px; }}
    figure {{ margin: 24px 0; }}
    figure img {{ width: 100%; height: auto; border: 1px solid #eee; }}
    figure figcaption {{ font-size: 0.9rem; opacity: 0.8; margin-top: 6px; }}
    .grid {{ display: grid; grid-template-columns: 1fr; gap: 20px; }}
    @media (min-width: 900px) {{ .grid {{ grid-template-columns: 1fr 1fr; }} }}
    .table {{ border-collapse: collapse; width: 100%; font-size: 0.95rem; }}
    .table th, .table td {{ border-bottom: 1px solid #eee; padding: 8px 10px; text-align: left; }}
    .muted {{ color: #666; }}
    code {{ background: #f7f7f7; padding: 2px 6px; border-radius: 4px; }}
    footer {{ padding: 24px; color: #666; }}
  </style>
</head>
<body>
  <header>
    <h1>Titanic Disaster – Exploratory Data Analysis</h1>
    <p class="muted">Auto-generated • {generated_at}</p>
  </header>
  <main>
    <section class="summary">
      <h2>Summary</h2>
      <ul>
        <li>Rows × columns: <b>{len(df)}</b> × <b>{df.shape[1]}</b></li>
        <li>Overall survival rate: <b>{df['Survived'].mean():.3f}</b></li>
        <li>Highest survival by Sex: <b>{gender_survival.idxmax()}</b> ({gender_survival.max():.3f})</li>
        <li>Best Pclass by survival: <b>{pclass_survival.idxmax()}</b> ({pclass_survival.max():.3f})</li>
      </ul>
      <p class="muted">Data used: <code>train.csv</code>.</p>
    </section>

    <section>
      <h2>Data quality</h2>
      <figure>
        <img src="assets/07_missingness_heatmap.png" alt="Heatmap of missing values across rows and columns">
        <figcaption>Heatmap of missing values. Bright cells indicate missing entries.</figcaption>
      </figure>
      <h3>Missing values by column</h3>
      {df_to_html_table(missing_sorted, index=True)}
      {"<p><b>High missingness (&ge; 30%):</b> " + ", ".join(high_missing.index.tolist()) + "</p>" if len(high_missing) else ""}
    </section>

    <section>
      <h2>Target & univariate distributions</h2>
      <figure>
        <img src="assets/01_target_distribution.png" alt="Bar chart of target distribution Survived 0 vs 1">
        <figcaption>Target distribution (<code>Survived</code>).</figcaption>
      </figure>
      <div class="grid">
        <figure>
          <img src="assets/06_fare_distribution_log.png" alt="Histogram of Fare on a log-scaled x-axis">
          <figcaption>Fare distribution (log-scaled x-axis).</figcaption>
        </figure>
        <figure>
          <img src="assets/05_age_by_outcome.png" alt="Overlaid histograms of Age for survived vs not survived">
          <figcaption>Age distributions by outcome.</figcaption>
        </figure>
      </div>
    </section>

    <section>
      <h2>Key relationships to survival</h2>
      <div class="grid">
        <figure>
          <img src="assets/02_survival_by_sex.png" alt="Bar chart of survival rate by Sex">
          <figcaption>Survival rate by <code>Sex</code>.</figcaption>
        </figure>
        <figure>
          <img src="assets/03_survival_by_pclass.png" alt="Bar chart of survival rate by Pclass">
          <figcaption>Survival rate by <code>Pclass</code>.</figcaption>
        </figure>
      </div>
      <div class="grid">
        <figure>
          <img src="assets/04_survival_by_embarked.png" alt="Bar chart of survival rate by Embarked">
          <figcaption>Survival rate by <code>Embarked</code>.</figcaption>
        </figure>
        <figure>
          <img src="assets/09_family_size_survival.png" alt="Bar chart of survival rate by FamilySize">
          <figcaption>Survival rate by <code>FamilySize</code> (SibSp + Parch + 1).</figcaption>
        </figure>
      </div>
      <h3>Correlation (numeric features)</h3>
      <figure>
        <img src="assets/08_correlation_heatmap.png" alt="Heatmap showing correlations among numeric features">
        <figcaption>Correlation heatmap for numeric features.</figcaption>
      </figure>
      <h3>Top correlations with the target</h3>
      {df_to_html_table(corr_with_target, index=True)}
    </section>
  </main>
  <footer>
    <p class="muted">This static site was generated with pandas and matplotlib.</p>
  </footer>
</body>
</html>
"""
    with open(os.path.join(docs_dir, "index.html"), "w", encoding="utf-8") as f:
        f.write(index_html)

if __name__ == "__main__":
    main()
