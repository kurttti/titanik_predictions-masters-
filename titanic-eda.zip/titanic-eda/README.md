# Titanic Disaster — Exploratory Data Analysis (EDA)

This repository contains a reproducible EDA for the classic Titanic dataset using your uploaded files.

**Live site (GitHub Pages):** after you push this repository, enable Pages for the `docs/` folder and your report will be served as a website.

## What’s inside

```
titanic-eda/
├─ docs/
│  ├─ index.html           # The EDA report (static)
│  └─ assets/              # All PNG charts used by the report
├─ generate_eda.py         # Script to regenerate charts & HTML locally
└─ requirements.txt        # Minimal Python deps
```

## How to publish on GitHub Pages

1. Create a new GitHub repository (e.g., `titanic-eda`).
2. Upload the contents of this folder to the repo (including the `docs/` directory).
3. In the repository, go to **Settings → Pages**:
   - **Source**: select `Deploy from a branch`
   - **Branch**: choose `main` (or `master`) and select the `/docs` folder
4. Save — your site will be published at a URL like `https://&lt;your-user&gt;.github.io/titanic-eda/`.

> If you prefer command line, you can:
>
> ```bash
> git init
> git add .
> git commit -m "Add Titanic EDA and site"
> git branch -M main
> git remote add origin https://github.com/&lt;your-user&gt;/titanic-eda.git
> git push -u origin main
> ```

## Reproducing locally

1. Ensure you have Python 3.9+.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Place your `train.csv`, `test.csv`, and `gender_submission.csv` in the same directory as `generate_eda.py` **or** pass their paths via CLI args (see below).
4. Run:
   ```bash
   python generate_eda.py
   ```
   This will (re)create `docs/index.html` and all images in `docs/assets/`.

---

Generated automatically on **2025-09-15 15:31 UTC**.
